AI学职同伴 DuMate 提交材料包（更新至 2026-10-11）

主作品对话（/s/）：https://www.dumate.cn/s/6ZVGwI8h
岗位展示附加页：https://www.dumate.cn/artifacts/2umsto0d4krz（现有作品广场页为 10-10 快照，本地更新版尚待重新发布）
GitHub：XFL11127/ai-career-companion
分支：feat/today-delivery-supabase-dashboard

应用方案 PDF 为 20 页、约 1.14 MB。岗位 CSV、来源说明、总览、本地展示页和 PDF 已同步至 10-11；中国移动在截止日当天仍显示投递入口，状态为 verified_closing_soon，截止后需再次复核。

本包含真实 DuMate 七步运行截图、公开分享页截图和 10-11 中国移动官网核验证据。DuMate 积分已用完，本轮没有再运行生成类 Skill，没有充值或升级。

iCAN 报名未提交；账号归属、组队信息和参赛协议/原创承诺仍待参赛人确认。公开作品广场更新版和最终材料发送组长也尚未完成。
